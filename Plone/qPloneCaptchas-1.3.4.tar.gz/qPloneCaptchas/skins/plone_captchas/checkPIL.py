## Script (Python) "checkPIL.py"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=actions=None
##title=
##
from Products.qPloneCaptchas.config import havePIL
return havePIL