from zope.interface import Interface

class ILocalBrowserLayerType(Interface):
    """Describes the type of interface an ILocalBrowserLayer is.
    """