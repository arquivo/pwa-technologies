from zope.interface import Interface

class IPloneFormGenThanksPage(Interface):
    """thanksPage marker interface
    """
