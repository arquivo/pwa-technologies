PFGDataGrid

 PFGDataGrid is an example of integrating a third-party Archetypes field/widget
 into PloneFormGen. It adds a DataGridField form field to PloneFormGen.

 To use it, copy the PDFDataGrid directory into the Products directory of your
 Plone instance.

 Use the QuickInstaller to install it *after* installing both PloneFormGen and
 DataGridField.

Requirements

 * PloneFormGen 1.1 or later;

 * DataGridField (tested with DGF 1.5-RC3)