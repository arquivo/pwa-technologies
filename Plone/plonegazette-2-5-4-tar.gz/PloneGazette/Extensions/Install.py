# $Id: Install.py 54371 2007-11-24 14:35:48Z naro $
#
__version__ = "1.0"

__doc__ = """Install script to setup your Product in CMF/Plone Site Instance"""

import os, glob, re
from cStringIO import StringIO

from Products.PloneGazette import NewsletterTheme, Newsletter, Subscriber, Section, NewsletterTopic, PROJECTNAME, product_globals
try:
    from Products.CMFCore.TypesTool import FactoryTypeInformation
    FTI = 1
except:
    from Products.CMFCore.TypesTool import ContentFactoryMetadata
    FTI = 0
from Products.CMFCore.DirectoryView import addDirectoryViews
from Products.CMFCore.utils import getToolByName

# archetypes import
from Products.Archetypes.Extensions.utils import installTypes
from Products.Archetypes import listTypes as AListTypes
from Products.Archetypes.utils import shasattr

class PloneSkinRegistrar:

    def __init__(self, skinsdir, prodglobals):
        """Constructor
        @param skinsdir: Name of the Product's subdirectory that
            contains the various layers for the Product.
        @type skinsdir: string
        @param prodglobals: Globals from this Product.

            should be provided by Product's C{__init__.py} like this:

            C{product_globals = globals()}

        @type propglobals: mapping object
        @return: None
        """

        self._skinsdir = skinsdir
        self._prodglobals = prodglobals
        return

    def install(self, aq_obj, layerName):
        """Installs and registers the skin resources
        @param aq_obj: object from which cmf site object is acquired
        @type aq_obj: any Zope object in the CMF
        @return: Installation log
        @rtype: string
        """

        rpt = '=> Installing and registering layers from directory %s\n' % self._skinsdir
        skinstool = getToolByName(aq_obj, 'portal_skins')

        # Create the layer in portal_skins
        if self._skinsdir not in skinstool.objectIds():
            addDirectoryViews(skinstool, self._skinsdir, self._prodglobals)
            rpt += 'Added "%s" directory view to portal_skins\n' % self._skinsdir
        else:
            rpt += 'Warning: directory view "%s" already added to portal_skins\n' % self._skinsdir

        # Insert the layer in all skins
        # XXX FIXME: Actually assumes only one layer directory with the name of the Product
        # (should be replaced by a smarter solution that finds individual Product's layers)

         
        #layerName = self._prodglobals['__name__'].split('.')[-1]
        
        skins = skinstool.getSkinSelections()
        for skin in skins:
            layers = skinstool.getSkinPath(skin)
            layers = [layer.strip() for layer in layers.split(',')]
            if layerName not in layers:
                try:
                    layers.insert(layers.index('content'), layerName)
                except ValueError:
                    layers.append(layerName)
                layers = ','.join(layers)
                skinstool.addSkinSelection(skin, layers)
                rpt += 'Added "%s" to "%s" skin\n' % (layerName, skin)
            else:
                rpt += '! Warning: skipping "%s" skin, "%s" is already set up\n' % (skin, type)
        return rpt

    def unInstall(self, aq_obj, layerName):

        rpt = '=> Uninstalling and unregistering %s layer\n' % self._skinsdir
        skinstool = getToolByName(aq_obj, 'portal_skins')

        # Removing layer from portal_skins
        # XXX FIXME: Actually assumes only one layer directory with the name of the Product
        # (should be replaced by a smarter solution that finds individual Product's layers)

        #layerName = self._prodglobals['__name__'].split('.')[-1]
        if layerName in skinstool.objectIds():
            skinstool.manage_delObjects([layerName])
            rpt += 'Removed "%s" directory view from portal_skins\n' % layerName
        else:
            rpt += '! Warning: directory view "%s" already removed from portal_skins\n' % layerName

        # Removing from skins selection

        skins = skinstool.getSkinSelections()
        for skin in skins:
            layers = skinstool.getSkinPath(skin)
            layers = [layer.strip() for layer in layers.split(',')]
            if layerName in layers:
                layers.remove(layerName)
                layers = ','.join(layers)
                skinstool.addSkinSelection(skin, layers)
                rpt += 'Removed "%s" to "%s" skin\n' % (layerName, skin)
            else:
                rpt += 'Skipping "%s" skin, "%s" is already removed\n' % (skin, layerName)
        return rpt
# /class PloneSkinRegistrar

class PloneTypeRegistrar:
    """Controls registering in a CMF site

        - (un)registering the type in 'portal_types'
        - (un)registering the layer in portal_skins
        - (un)inserting the layer in the path of all skins

    Feel frere to copy/paste this class to your own Product's
    registering script like the one where you found it.

    Please send comments to the author.

    @author: U{Pilot Systems <info@pilotsystems.net>}
    @version: 0.1.0
    """

    def __init__(self, klass):
        """
        @param klass: CMF class to get install information
        @type klass: CMF content class
        """

        self._klass = klass
        return

    def _formMapping(self):
        """Mapping of properties for portal_properties/form_properties
        """

        return self._klass.form_properties_information

    def _navMapping(self):
        """Mapping of properties for portal_properties/navigation_properties
        """
        return self._klass.navigation_properties_information
    
    def install(self, aq_obj):
        """Performs resources registration into a CMF site
        @param aq_obj: object from which cmf site object is acquired
        @type aq_obj: any Zope object in the CMF
        @return: a short report about what has been done
        @rtype: string
        """

        rpt = ''
        typestool = getToolByName(aq_obj, 'portal_types')

        fti = self._klass.factory_type_information
        for action in fti['actions']:
	        action['title'] = action['name']
	        action['condition'] = ''
        id = fti['id']
        type = fti['meta_type']
        rpt += ("=> Installing ressources for using %s Product's types in this CMF site\n"
                % type)
        if id not in typestool.objectIds():
            if FTI:
                ftinfo = FactoryTypeInformation(**fti )
                typestool._setObject( id, ftinfo )
            else:
                cfm = apply(ContentFactoryMetadata, (), fti)
                typestool._setObject(id, cfm)
            rpt += 'Type "%s" registered in the types tool\n' % id
        else:
            rpt += '! Warning: type "%s" already registered in the types tool\n' % id

        return rpt
    # /def install
    
    def unInstall(self, aq_obj):
        """Removes resources registration from a CMF site
        @param aq_obj: object from which cmf site object is acquired
        @type aq_obj: any Zope object in the CMF
        @return: a short report about what has been done
        @rtype: string
        @see: install
        """

        rpt = ''
        typestool = getToolByName(aq_obj, 'portal_types')

        fti = self._klass.factory_type_information
        id = fti['id']
        type = fti['meta_type']
        rpt += ("=> Uninstalling ressources for using %s Product's types in this CMF site\n"
                % type)
        if id in typestool.objectIds():
            typestool.manage_delObjects([id])
            rpt += 'Removed "%s" from the types tool\n' % id
        else:
            rpt += '! Warning: type "%s" already removed from the types tool\n' % id

        return rpt
    # /def unInstall
# /class PloneTypeRegistrar

TR = (NewsletterTheme.NewsletterTheme, Newsletter.Newsletter, Subscriber.Subscriber, Section.Section, NewsletterTopic.NewsletterTopic)

def installInfo(self):
    """Provides registering data used to (un)install YOUR product.
    Tailor this to reflect your Product's (un)registering information
    Usually, CMF Products may install one skin and one or more types
    @return: tuple of registering information
    @rtype: (PloneTypeRegistrar, PloneSkinRegistrar)
    """
    # We (un)register the types provided with this class
    tr = [PloneTypeRegistrar(i) for i in TR]
    # We (un)register the layer from /path/to/thisproduct/skins/thisproduct
    sr = [('PloneGazette', PloneSkinRegistrar('skins', product_globals))]
    return tr, sr

def install(self):
    """Installation
    Create an External method in your CMF/Plone object:
     - Id: myCMFProductInstaller (or whatever you want)
     - Title: (whatever you want)
     - Module Name: MyCMFProduct.Install
     - Function Name: install
    Then click the "Test" tab and have a look to the printed report
    for potential warnings.
    @return: Full installation report
    """
    out = StringIO()
    tr, sr = installInfo(self)
    for registrar in tr:
        out.write(registrar.install(self))
    for x in sr:
        out.write(x[1].install(self, x[0]))
    # archetypes install
    classes = AListTypes(PROJECTNAME)
    installTypes(self, out, classes, PROJECTNAME)
    
    wtool = getToolByName(self, 'portal_workflow')
    wtool.setChainForPortalTypes(('Subscriber',), ())
    out.write('Disabled Subscriber workflow') 
    
    migrateAttributes(self)
    
    return out.getvalue()

def unInstall(self):
    """Uninstallation
    Create an External method in your CMF/Plone object:
     - Id: myCMFProductUninstaller (or whatever you want)
     - Title: (whatever you want)
     - Module Name: myCMFProduct.Install
     - Function Name: unInstall
     Then click the "Test" tab and have a look to the printed report
     for potential warnings.
    @return: Full uninstallation report
    """
    out = StringIO()
    tr, sr = installInfo(self)
    for registrar in tr:
        out.write(registrar.unInstall(self))
    for x in sr:
        out.write(x[1].unInstall(self, x[0]))

    # archetypes uninstall
    
    return out.getvalue()

def migrateAttributes(self):
    """ Migrate Newsletter instances to have all required attributes
    """
    ctool = getToolByName(self, 'portal_catalog')
    nls = ctool(portal_type='Newsletter')
    for nl in nls:
        obj = nl.getObject()
        if obj is not None:
            if not shasattr(obj, '_dynamic_content'):
                setattr(obj, '_dynamic_content', None)
                obj._p_changed = 1
            
    