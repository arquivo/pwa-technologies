from Products.CMFCore import permissions as cmfcore_permissions

## This file is used to set up permissions for product.

ADD_PERMISSION = cmfcore_permissions.AddPortalContent
