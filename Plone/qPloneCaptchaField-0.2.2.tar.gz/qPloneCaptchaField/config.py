PROJECTNAME = "qPloneCaptchaField"
SKINS_DIR = "skins"
GLOBALS = globals()