Plone Capcha Field

    qPloneCaptchaField is a Plone product that allows to add captcha field to the form, created with PloneFormGen product.

Supported Plone versions:

    * 3.x

Dependencies

    * PloneFormGen
    * qPloneCaptchas

Installation:

    Please make sure that the following products are intalled in the following order:

    * PloneFormGen

    * qPloneCaptchas

    * qPloneCaptchaField

Documentation:

    http://projects.quintagroup.com/products/wiki/qPloneCaptchaField

Authors:

    The product is developed by Quintagroup.com team:

    * Volodymyr Cherepanyak - chervol@quintagroup.com

    * Taras Melnychuk - fenix@quintagroup.com
