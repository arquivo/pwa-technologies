from zope.interface import Interface

class IPloneFormGenFieldset(Interface):
    """fgFieldsetForm marker interface
    """

