"""
    Module initialization code
    
    Used by PloneFormGen/__init__.py

"""
import fields, form, fieldset
import actionAdapter, saveDataAdapter, formMailerAdapter
import customScriptAdapter
import thanksPage
import likertField, formLikertField