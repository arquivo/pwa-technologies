from plone.theme.interfaces import IDefaultPloneLayer

class IPloneCommentsLayer(IDefaultPloneLayer):
    """Marker interface that defines a Zope 3 skin layer bound to a Skin
       Selection in portal_skins.
    """
