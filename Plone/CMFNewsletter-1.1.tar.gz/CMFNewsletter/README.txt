CMFNewsletter README

   CMFNewsletter enables you to create one or more newsletters for your site.
   Each newsletter gathers content using topic-based criteria. Subscription
   can be restricted to members only, made available to anonymous or another
   custom set of members, via workflow guards.
   
   Subscription is done via the web, and by email if you set up PortalTransport
   and an email address for your newsletter.
   
   The newsletter is a page template, which you can customize. You can also 
   invoke a pre-processing script before the newsletter is generated, which
   is useful for adding additional email header data or manipulating the content
   gathered.

   Newsletters are kept by default in the portal_newsletters tool, because
   normally newsletters should not be viewed in the site - only by receiving 
   through email. There is no archiving option to view older newsletters. You can add
   and manage newsletters through the control panel. It is possible to create 
   newsletters outside of the tool, by checking the Implicitly Addable property
   of the Newsletter content type in portal_types.
  

Prerequisites:

   * Zope 2.6.2+ (www.zope.org)

   * CMF 1.4.2+ (cmf.zope.org)

   * Plone 2.0+ (www.plone.org)

   * ArcheTypes 1.2.4 (http://sourceforge.net/projects/archetypes/)

   * PortalTransport 1.1+ (http://sourceforge.net/projects/collective/)

   * CMFTopic


   * Optional:

     * ZopeScheduler 0.2 (http://dev.legco.biz/products/ZopeScheduler)
       cronlike service


Install

    Use CMFQuickInstallerTool for this
    
Pre-processing of newsletter

   You can create scripts to do some work before the template is 
   processed. See PortalTransport README.txt for more details.

   Add scripts in the portal_mailtemplates tool. 
   Go to your site, click on portal_mailtemplates and then click 
   on the Scripts tab. Add python scripts here.

   Add the following parameters to your script:
   parameters=info, headers, charset, files

   The following variables can be used in the pre-processing script:
   
   info[contents]    - list of newsletter contents (catalog brains)
   info[newsletter]  - newsletter instance
   info[title]       - newsletter title
   info[description] - newsletter description
   info[url]         - newsletter url
   info[member]	     - member object. it only available for non
		       anonymous subscriber and 
		       if 'Generate emails for each subscriber' option
		       checked

   headers[from]     - from address
   headers[bcc]      - addresses of subscribers
   headers[message-id] - email message id

   files[]           - message attachements
   
   charset           - character set encoding for message
   
   You can append additional information to any of the lists above for use
   in your newsletter template.
   
   examples:

   # add custom email header
   headers['X-Organization'] = 'CMFBoard.org'
   
   # add file to email message
   files.append((context['folder_icon.gif'], 'image/gif', 'folder_icon.gif'))
   
Subscription templates

   See PortalTransport/README.txt for more information.

Bugs
 
   Report bugs to sf.net/projects/collective, using the CMFNewsletter category.
