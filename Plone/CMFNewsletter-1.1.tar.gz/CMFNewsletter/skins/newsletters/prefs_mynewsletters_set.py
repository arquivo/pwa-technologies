## Script (Python) "prefs_mynewsletters_set"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=newsletters
##title=set
##

tool = context.archetype_tool

for newsletter in newsletters:
    ob = tool.lookupObject(newsletter['uid'])
    if ob is not None:
        subs_info = ob.isSubscribed()
        if newsletter.has_key('isSubs'):
            if subs_info == 0:
                ob.subscribe()
        else:
            if subs_info:
                ob.unsubscribe()

request = context.REQUEST
member = context.portal_membership.getAuthenticatedMember()
member.setProperties(request)

return request.RESPONSE.redirect(
    '%s/prefs_mynewsletters_form?portal_status_message=Your subscriptions saved.'%context.absolute_url())
