## Script (Python) "cronSend"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=
##
# Used for automating the send of all newsletters
# The script MUST return an empty string
# This script should be restricted to use by
# Managers only via .metadata security settings

context.portal_newsletters.sendNewsletters()
    
return ''
