# -*- coding: UTF-8 -*-
# -*- Mode: Python; py-indent-offset: 4 -*-
# Authors: Nik Kim <fafhrd@legco.biz>

import traceback
from Globals import InitializeClass
from AccessControl import ClassSecurityInfo
from Products.CMFCore.CMFCorePermissions import View

try:
    from ZopeScheduler.BaseSchedulingTask import CMFSchedulingTask

    class SchedulingTask(CMFSchedulingTask):
        
        security = ClassSecurityInfo()

        security.declarePrivate('process_task')
        def process_task(self):
            self.sendMessage(self)

    InitializeClass(SchedulingTask)
    
except ImportError:
    
    class SchedulingTask:
        __implements__ = ()

        security = ClassSecurityInfo()

        security.declareProtected(View, 'isSchedulerAvailable')
        def isSchedulerAvailable(self):
            """ """
            return 0

    InitializeClass(SchedulingTask)
