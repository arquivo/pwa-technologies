# -*- coding: UTF-8 -*-
# -*- Mode: Python; py-indent-offset: 4 -*-
# Author: Nik Kim <fafhrd@legco.biz>
__version__ = '$Revision: 1.7 $'[11:-2]

from OFS.Folder import Folder
from Globals import InitializeClass
from Acquisition import aq_parent, aq_inner, aq_base
from AccessControl import ClassSecurityInfo
from Products.CMFCore.CMFCorePermissions import View, ManagePortal
from Products.CMFCore.utils import UniqueObject, _checkPermission
from Products.PageTemplates.PageTemplateFile import PageTemplateFile

import Newsletter
from config import PROJECTNAME, SendNewsletter

class NewslettersTool(UniqueObject, Folder):
    """ """
    security = ClassSecurityInfo()

    id = 'portal_newsletters'
    title = 'Manage portal newsletters'
    meta_type= 'Newsletters Tool'

    security.declareProtected(SendNewsletter, 'sendNewsletter')
    def sendNewsletter(self, ids=[], REQUEST=None):
        """ """
        obs = [self._getOb(id, None) for id in ids]
        obs = [ob for ob in obs if ob is not None]

        for ob in obs:
            if _checkPermission(SendNewsletter, ob):
                ob.sendNewsletter()

        msg = 'Newsletters have been sent.'
        
    security.declareProtected(SendNewsletter, 'sendNewsletters')
    def sendNewsletters(self, REQUEST=None):
        """ """
        nls = self.getNewsletters()
        for nl in nls:
            nl.sendNewsletter()

    security.declareProtected(View, 'getNewsletters')
    def getNewsletters(self):
        """ """
        portal = aq_parent(aq_inner(self))
        props = portal.portal_properties.cmfnewsletter_properties
        use_outside = props.allow_outside_nl
        
        nls = []
        if use_outside:
            portal = aq_parent(aq_inner(self))
            for brain in portal.portal_catalog(Type='Newsletter'):
                try:
                    nl = brain.getObject()
                    if nl is not None:
                        nls.append(nl)
                except:
                    pass
        else:
            for nl in self.objectValues():
                try:
                    if ((nl.Type() == 'Newsletter') and
                        _checkPermission(View, nl)):
                        nls.append(nl)
                except AttributeError:
                    pass
        return nls
        
    security.declareProtected(ManagePortal, 'createNewsletter')
    def createNewsletter(self, id, title='', REQUEST=''):
        """ """
        if not hasattr(aq_base(self), id):
            self.manage_addProduct[
                PROJECTNAME].manage_addContent(id, 'Newsletter')
            ob = getattr(self, id)
            ob.getField('title').set(ob, title)
        else:
            ob = getattr(self, id)
        ob.indexObject()
        if hasattr(aq_base(ob), 'notifyWorkflowCreated'):
            ob.notifyWorkflowCreated()
        
        if REQUEST is not None:
            return REQUEST.RESPONSE.redirect(
                '%s/prefs_newsletters?portal_status_message=Newsletter added.'%(
                aq_parent(aq_inner(self)).absolute_url()))
        return ob

InitializeClass( NewslettersTool )
