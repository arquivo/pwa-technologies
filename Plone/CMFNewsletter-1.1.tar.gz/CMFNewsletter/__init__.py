__version__ = '$Revision: 1.3 $'[11:-2]

from Globals import package_home
from Products.Archetypes.public import process_types, listTypes
import Products.CMFCore.utils as cmfcore_utils
from Products.CMFCore.utils import getToolByName
from Products.CMFCore.DirectoryView import registerDirectory

from config import SKINS_DIR, GLOBALS, PROJECTNAME
from config import ADD_CONTENT_PERMISSION

registerDirectory(SKINS_DIR, GLOBALS)

import mailtemplates, workflows
import NewslettersTool, Newsletter

tools = (NewslettersTool.NewslettersTool,)

def initialize(context):
    content_types, constructors, ftis = process_types(
        listTypes(PROJECTNAME),
        PROJECTNAME)

    cmfcore_utils.ContentInit(
        PROJECTNAME + ' Content',
        content_types      = content_types,
        permission         = ADD_CONTENT_PERMISSION,
        extra_constructors = constructors,
        fti                = ftis,
        ).initialize(context)

    cmfcore_utils.ToolInit(
        PROJECTNAME + ' Tools'
        , tools = tools
        , product_name = PROJECTNAME
        , icon='tool.gif'
        ).initialize(context)
