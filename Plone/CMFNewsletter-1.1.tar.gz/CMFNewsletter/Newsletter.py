# -*- coding: UTF-8 -*-
# -*- Mode: Python; py-indent-offset: 4 -*-
# Authors: Nik Kim <fafhrd@legco.biz>
"""
$Id: Newsletter.py,v 1.30 2004/03/15 10:42:34 fafhrd91 Exp $
"""

import traceback
from Globals import InitializeClass
from Acquisition import aq_base
from AccessControl import ClassSecurityInfo
from AccessControl.SecurityManagement import newSecurityManager, noSecurityManager
from Acquisition import aq_base
from Products.ZCatalog.ZCatalog import ZCatalog
from Products.CMFCore.CMFCorePermissions import \
     View, ModifyPortalContent, ManageProperties, AccessInactivePortalContent
from Products.Archetypes.public import *
from Products.CMFCore.utils import getToolByName, _checkPermission
from Products.CMFTopic.Topic import Topic
from Products.PortalTransport.public import *
from Products.PortalTransport.interfaces.mailreceiver import IMailReceiver
from Products.PortalTransport.PortalTransportPermissions import AllowSubscription

from email.Utils import formataddr

from config import *
from SchedulingTask import SchedulingTask

class Newsletter(BaseFolder, SubscribeableMember, SubscribeableAnonymous,
                 Topic, SchedulingTask):
    """ """
    meta_type = 'Newsletter'
    archetype_name = 'Newsletter'

    __implements__ = (BaseFolder.__implements__ +
                      SubscribeableMember.__implements__ +
                      SubscribeableAnonymous.__implements__ +
                      SchedulingTask.__implements__)

    global_allow = 0
    filter_content_types = 1
    allowed_content_types = []
    content_icon = 'mail_icon.gif'

    schema = BaseSchema + Schema((
        BooleanField('generate_emails', required=0, default=0,
                     write_permission=ModifyPortalContent,
                     widget=BooleanWidget(label='Generate emails for each subscriber',
                                          label_msgid='label_generate_emails',
                                          description_msgid='help_generate_emails',
                                          i18n_domain='CMFNewsletter',)),
        BooleanField('auto_activate_anon', required=0, default=0,
                     write_permission=ModifyPortalContent,
                     widget=BooleanWidget(label='Auto Activation Anonymous Subscription',
                                          label_msgid='label_auto_activate_anon',
                                          description_msgid='help_auto_activate_anon',
                                          i18n_domain='CMFNewsletter',)),
        StringField('mailtemplate_html', required=0, default=mailtemplate_html,
                    write_permission=ModifyPortalContent,
                    vocabulary= '_get_mail_template',
                    widget=SelectionWidget(label='Mail template (HTML)',
                                           label_msgid='label_mailtemplate_html',
                                           description_msgid='help_mailtemplate_html',
                                           i18n_domain='CMFNewsletter',
                                           format='select')),
        StringField('mailtemplate_plain', required=0, default=mailtemplate_plain,
                    write_permission=ModifyPortalContent,
                    vocabulary= '_get_mail_template',
                    widget=SelectionWidget(label='Mail template (Plain)',
                                           label_msgid='label_mailtemplate_plain',
                                           description_msgid='help_mailtemplate_plain',
                                           i18n_domain='CMFNewsletter',
                                           format='select')),
        TextField('description', required=0, default='',
                  searchable=1,
                  write_permission=ModifyPortalContent,
                  widget=TextAreaWidget(label_msgid='label_description',
                                        description_msgid='help_description',
                                        i18n_domain='plone')),
        ))

    actions = (
            { 'id': 'view',
              'name': 'View',
              'action': 'string:$object_url/newsletter_view',
              'permissions': (ModifyPortalContent,)
              },
            { 'id': 'edit',
              'name': 'Edit',
              'action': 'string:$object_url/base_edit',
              'permissions': (ModifyPortalContent,)
              },
            { 'id': 'criteria',
              'name': 'Criteria',
              'action': 'string:$object_url/topic_criteria_form',
              'permissions': (ModifyPortalContent,)
              },
            { 'id': 'subscription',
              'name': 'Subscription',
              'action': 'string:$object_url/pt_subscription_form',
              'condition': 'not:member',
              'permissions': (AllowSubscription,)
              },
            { 'id': 'newsletter_send',
              'name': 'Send',
              'action': 'string:$object_url/sendNewsletter',
              'permissions': (SendNewsletter,),
              'category': 'object_actions'
              },
            { 'id': 'subscribers',
              'name': 'Subscribers',
              'action': 'string:$object_url/pt_subscribers_form',
              'permissions': (ModifyPortalContent,)
              },
            { 'id': 'scheduler',
              'name': 'Scheduler',
              'action': 'string:$object_url/schedulingtask_edit_form',
              'permissions': (ModifyPortalContent,),
              'condition': 'object/isSchedulerAvailable',
              },
            )

    security = ClassSecurityInfo()

    def manage_afterAdd(self, item, container):
        BaseFolder.manage_afterAdd(self, item, container)

        try:
            self.addCriterion('modified', 'Friendly Date Criterion')
            self.addCriterion('Type', 'List Criterion')
            crit = self.getCriterion('Type')
            crit.edit(('Document', 'News Item'))
        except:
            pass

    security.declareProtected(ModifyPortalContent, 'setTitle')
    def setTitle(self, value, **kwargs):
        """We have to override setTitle here to handle arbitrary
        arguments since PortalFolder defines it."""
        self.getField('title').set(self, value, **kwargs)

    security.declareProtected(ModifyPortalContent, 'setDescription')
    def setDescription(self, value, **kwargs):
        """We have to override setDescription here to handle arbitrary
        arguments since PortalFolder defines it."""
        self.getField('description').set(self, value, **kwargs)

    def _get_mail_template(self):
        res = []
        for ob in self.portal_mailtemplates.CMFNewsletter.contentValues():
            res.append((ob.getId(), ob.title_or_id()))
        return DisplayList((res))


    ####################################
    #  Subscribeable API
    ####################################
    security.declareProtected(AllowSubscription, 'isAutoActivateAnonymousSubscription')
    def isAutoActivateAnonymousSubscription(self):
	""" auto activate or start activate process """
        return self.getField('auto_activate_anon').get(self)

    security.declareProtected(SendNewsletter, 'sendNewsletter')
    def sendNewsletter(self, txt_message='', REQUEST=None):
        """ """
        self.sendMessage(self, txt_message=txt_message)

        if REQUEST is not None:
            REQUEST.RESPONSE.redirect('%s?portal_status_message=%s'%(
                self.absolute_url(), 'Newsletter has been sent.'))

    security.declarePrivate('sendMessage')
    def sendMessage(self, message, txt_message=''):
        """ send newsletter to all subsribed users """
        portal = getToolByName(self, 'portal_url').getPortalObject()
        pmt = portal.portal_mailtemplates
        mtool = portal.portal_membership

        subs = portal.portal_subscriptions.getSubscriptions(
            self, review_state=('active', 'deactivation'))

        if not subs:
            return

        mailspool = portal.portal_mailspool
        newsletter_html = self.getField('mailtemplate_html').get(self)
        newsletter_plain = self.getField('mailtemplate_plain').get(self)

        headers = {}

        # get additional headers from portal_mailtransport
        mtinfo = self.getBRefs(mtinfo_relation)
        if mtinfo:
            mt_headers = mtinfo[0].getHeaders()

            return_path = mtinfo[0].getReturnPath()
            
            headers['From'] = formataddr((self.Title(), mt_headers['reply-to']))
            headers.update(mt_headers)
        else:
            return_path = self.email_from_address
            headers['From'] = formataddr((self.Title(), return_path))


        if not self.getField('generate_emails').get(self):
            # send one message to all users
            plain = []
            html = []
            for si in subs:
                member_id = si.member_id
                if member_id != 'Anonymous User':
                    member = mtool.getMemberById(member_id)
                    if member is None:
                        continue
                    
                    text_format = member.getProperty('newsletter_format', 'plain')
                else:
                    text_format = si.getTextFormat()
                    
                if text_format == 'html':
                    html.append(si.getEmail())
                else:
                    plain.append(si.getEmail())

            if not (plain or html):
                return
            
            headers['To'] = headers['From']

            contents = []
            for brain in self.queryCatalog():
                try:
                    ob = brain.getObject()
                    if ob is not None:
                        contents.append(ob)
                except:
                    pass

            if not contents:
                return

            info = {
                'contents': contents,
                'newsletter': self,
                'title': self.Title(),
                'description': self.Description(),
                'url': self.absolute_url(),
                'member': None,
		'message': txt_message,
                }

            if plain:
                #headers['Bcc'] = '%s'%','.join([m for m in plain])
                message = pmt.createMessage(
                    PROJECTNAME, newsletter_plain, info, headers)
                mailspool.sendmail(return_path, plain, message)

            if html:
                #headers['Bcc'] = '%s'%','.join([m for m in html])
                message = pmt.createMessage(
                    PROJECTNAME, newsletter_html, info, headers, text_format='html')
                mailspool.sendmail(return_path, html, message)
        else:
            # get all content
            kw = self.buildQuery()
            catalog = portal.portal_catalog
            if not _checkPermission( AccessInactivePortalContent, catalog ):
                now = DateTime()
                kw[ 'effective' ] = { 'query' : now, 'range' : 'max' }
                kw[ 'expires'   ] = { 'query' : now, 'range' : 'min' }

            all_contents = []
            for brain in ZCatalog.searchResults(catalog, **kw):
                try:
                    ob = brain.getObject()
                    if ob is not None:
                        all_contents.append(ob)
                except:
                    continue

            if not all_contents:
                return

            # send message to each subscriber
            info = {
                'newsletter': self,
                'title': self.Title(),
                'description': self.Description(),
                'url': self.absolute_url(),
		'message': txt_message,
                }

            for si in subs:
                # check if user can view this message
                if si.member_id != 'Anonymous User':
                    member = mtool.getMemberById(si.member_id)
                    if member is None:
                        continue
                    
                    user = member.getUser()
                    if user is None:
                        continue

                    info['member'] = member

                    user = user.__of__(portal.acl_users)
                    newSecurityManager(None, user)
                    text_format = member.getProperty('newsletter_format', 'plain')
                else:
                    noSecurityManager()
                    text_format = si.getTextFormat()
                    info['member'] = None
                                        
                contents = []
                for ob in all_contents:
                    if _checkPermission(View, ob):
                        contents.append(ob)

                if not contents:
                    noSecurityManager()
                    continue

                headers['To'] = si.getEmail()
                info['contents'] = contents
                    
                if text_format == 'html':
                    message = pmt.createMessage(
                        PROJECTNAME, newsletter_html, info, headers, text_format='html')
                else:
                    message = pmt.createMessage(PROJECTNAME, newsletter_plain, info, headers)

                mailspool.sendmail(return_path, headers['To'], message)
                noSecurityManager()


def modify_fti(fti):
    for a in fti['actions']:
        if a['id'] in ('metadata', 'references', ):
            a['visible'] = 0
    return fti

registerType(Newsletter)
