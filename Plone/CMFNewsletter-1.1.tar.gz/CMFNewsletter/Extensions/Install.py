__version__ = '$Revision: 1.11 $'[11:-2]

import traceback
from cStringIO import StringIO
from Acquisition import aq_base
from Products.CMFCore.utils import getToolByName
from Products.Archetypes.public import listTypes
from Products.Archetypes.Extensions.utils import installTypes, install_subskin
from Products.PortalTransport.utils import install_mail_templates

from Products.CMFNewsletter.config import *
from Products.CMFNewsletter.mailtemplates import templates
from Products.CMFNewsletter.workflows import \
     newsletter_workflow, newsletter_workflow_id
from Products.CMFNewsletter.NewslettersTool import NewslettersTool

def install(self):
    out = StringIO()

    portal = getToolByName(self, 'portal_url').getPortalObject()
    wtool = portal.portal_workflow

    if hasattr(portal, 'portal_quickinstaller'):
        portal.portal_quickinstaller.installProduct('PortalTransport')

    installTypes(self, out, listTypes(PROJECTNAME), PROJECTNAME)
    install_subskin(self, out, GLOBALS)
    install_mail_templates(self, self.portal_url.getPortalObject(), templates, out)
    install_global_properties(self, portal, out)

    if newsletter_workflow_id in wtool.objectIds():
        wtool._delObject(topic_workflow_id)

    wtool.manage_addWorkflow(id=newsletter_workflow_id, workflow_type=newsletter_workflow)
    wtool.setChainForPortalTypes(('Newsletter',), newsletter_workflow_id)
    print >> out, "Successfully installed custom workflows."

    mdtool = portal.portal_memberdata
    for prop, tp, val in memberData_properties:
        if not mdtool.hasProperty(prop):
            mdtool._setProperty(prop, val, tp)

    try:
        self.portal_controlpanel.registerConfiglet(**mynewsletters_configlet)
        self.portal_controlpanel.registerConfiglet(**newsletterstool_configlet)
    except:
        pass

    if not hasattr(portal, 'portal_newsletters'):
        portal.manage_addProduct[PROJECTNAME].manage_addTool(
            NewslettersTool.meta_type, None)
        print >> out, "Successfully installed Newsletters Tool."

    # install left_slots
    left_slots = getattr(portal, 'left_slots', [])
    if not callable(left_slots) and newsletters_slot not in left_slots:
        try:
            left_slots.insert(2, newsletters_slot)
        except:
            left_slots.append(newsletters_slot)
        portal.left_slots = tuple(left_slots)

    print >> out, "Successfully installed %s." % PROJECTNAME
    
    return out.getvalue(templates)

def install_global_properties(self, portal, out):
    # install mailtransport properties
    portal_properties = portal.portal_properties
    props = portal_properties.portaltransport_properties
    types = list(props.types)
    for tp in ['Newsletter',]:
        if tp not in types:
            types.append(tp)
    props.types = tuple(types)


    if not hasattr(portal_properties, properties):
        portal_properties.addPropertySheet(
            properties, '%s properties'%PROJECTNAME)

    props = getattr(portal_properties, properties)
    for prop, tp, val in newsletter_properties:
        if not props.hasProperty(prop):
            props._setProperty(prop, val, tp)

    print >> out, "Successfully installed global properties."


def uninstall(self):
    out = StringIO()

    # uninstall configs
    try:
        self.portal_controlpanel.unregisterApplication(PROJECTNAME)
    except:
        pass
        
    print >> out, "Successfully uninstalled %s." % PROJECTNAME
    return out.getvalue()


    
