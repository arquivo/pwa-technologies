# -*- coding: UTF-8 -*-
# -*- Mode: Python; py-indent-offset: 4 -*-
# Authors: Nik Kim <fafhrd@legco.biz>
"""
$Id: workflows.py,v 1.2 2004/01/20 19:32:42 fafhrd91 Exp $
"""

from Products.CMFCore.CMFCorePermissions import \
     View, ModifyPortalContent, AccessContentsInformation, \
     ReviewPortalContent, RequestReview

from Products.CMFCore.WorkflowTool import addWorkflowFactory
from Products.DCWorkflow.DCWorkflow import DCWorkflowDefinition
from Products.DCWorkflow.Transitions import TRIGGER_AUTOMATIC
from Products.PythonScripts.PythonScript import manage_addPythonScript

from Products.PortalTransport.PortalTransportPermissions import AllowSubscription

p_access = AccessContentsInformation
p_modify = ModifyPortalContent
p_view = View
p_subscription = AllowSubscription
p_review = ReviewPortalContent

r_anon = 'Anonymous'
r_manager = 'Manager'
r_member = 'Member'
r_owner = 'Owner'


def setupNewsletterWorkflow(wf):
    wf.setProperties(title='Newsletter Workflow [CMFNewsletter]')

    for s in ('public', 'members', 'custom'):
        wf.states.addState(s)
    for t in ('public', 'members', 'custom'):
        wf.transitions.addTransition(t)
    for v in ('action', 'actor', 'comments', 'review_history', 'time'):
        wf.variables.addVariable(v)
    for p in (p_access, p_view, p_subscription, p_modify):
        wf.addManagedPermission(p)

    # states
    wf.states.setInitialState('public')

    sdef = wf.states['members']
    sdef.setProperties(
        title='Only members can subscribe to this newsletter',
        transitions=('public', 'custom'))
    sdef.setPermission(p_view, 0, (r_manager, r_member, r_owner))
    sdef.setPermission(p_access, 0, (r_manager, r_member, r_owner))
    sdef.setPermission(p_modify, 0, (r_manager, r_owner))
    sdef.setPermission(p_subscription, 0, (r_manager, r_member, r_owner))

    sdef = wf.states['public']
    sdef.setProperties(
        title='Members and Anonymous can subscribe to this newsletter',
        transitions=('members', 'custom'))
    sdef.setPermission(p_view, 1, ())
    sdef.setPermission(p_access, 1, ())
    sdef.setPermission(p_modify, 0, (r_manager, r_owner))
    sdef.setPermission(p_subscription, 0, (r_manager, r_member, r_owner, r_anon))

    sdef = wf.states['custom']
    sdef.setProperties(
        title='Manager can define his own permissions',
        transitions=('public', 'members'))
    sdef.setPermission(p_view, 0, (r_manager, r_owner))
    sdef.setPermission(p_access, 0, (r_manager, r_owner))
    sdef.setPermission(p_modify, 0, (r_manager, r_owner))
    sdef.setPermission(p_subscription, 0, (r_manager, r_owner))

    # transitions
    tdef = wf.transitions['members']
    tdef.setProperties(
        title='Members newsletter',
        new_state_id='members',
        actbox_name='Members newsletter',
        props={'guard_permissions':p_review})

    tdef = wf.transitions['public']
    tdef.setProperties(
        title='Public newsletter',
        new_state_id='public',
        actbox_name='Public newsletter',
        props={'guard_permissions':p_review})

    tdef = wf.transitions['custom']
    tdef.setProperties(
        title='Custom newsletter',
        new_state_id='custom',
        actbox_name='Custom newsletter',
        props={'guard_permissions':p_review})

    # variables
    wf.variables.setStateVar('review_state')

    vdef = wf.variables['action']
    vdef.setProperties(description='The last transition',
                       default_expr='transition/getId|nothing',
                       for_status=1, update_always=1)

    vdef = wf.variables['actor']
    vdef.setProperties(description='The ID of the user who performed '
                       'the last transition',
                       default_expr='user/getId',
                       for_status=1, update_always=1)

    vdef = wf.variables['comments']
    vdef.setProperties(description='Comments about the last transition',
                       default_expr="python:state_change.kwargs.get('comment', '')",
                       for_status=1, update_always=1)

    vdef = wf.variables['review_history']
    vdef.setProperties(description='Provides access to workflow history',
                       default_expr="state_change/getHistory",
                       props={'guard_permissions': p_review})

    vdef = wf.variables['time']
    vdef.setProperties(description='Time of the last transition',
                       default_expr="state_change/getDateTime",
                       for_status=1, update_always=1)


def createNewsletterWorkflow(id):
    ob = DCWorkflowDefinition(id)
    setupNewsletterWorkflow(ob)
    return ob

addWorkflowFactory(createNewsletterWorkflow, id='newsletter_workflow',
                   title='Newsletter Workflow [CMFNewsletter]')

newsletter_workflow = 'newsletter_workflow (Newsletter Workflow [CMFNewsletter])'
newsletter_workflow_id = 'newsletter_workflow'
