# -*- coding: UTF-8 -*-
# -*- Mode: Python; py-indent-offset: 4 -*-
# Authors: Nik Kim <fafhrd@legco.biz>
"""
$Id: mailtemplates.py,v 1.12 2004/02/22 05:44:54 damonlynch Exp $
"""

from config import PROJECTNAME

newsletter_html = {'title': 'Newsletter Template (HTML)',
                   'description': 'Default Newsletter Template.',
                   'mail_subject': "python:'%s - %s'%(options['title'], portal.toPortalTime(modules['DateTime'].DateTime(), 1))",
                   'mail_body':
"""
<h2 tal:content="options/title"></h2>
<p tal:content="options/description"></p>
<tal:block content="python:options['portal'].toPortalTime(modules['DateTime'].DateTime(), 1)" />
<br />
<div tal:content="structure options/message"></div>

<div tal:repeat="content options/contents">
  <h4 tal:content="content/Title"></h4>
  <div class="description">
    <div tal:content="content/Description"></div>
    <a tal:content="content/absolute_url" tal:attributes="href content/absolute_url"></a>
  </div>
  <br />  
</div>

_____________________________<br />
<a tal:attributes="href string:${options/portal_url}/prefs_mynewsletters_form" i18n:translate="label_unsubscribe">Unsubscribe</a><br />
<a tal:content="options/portal_title" tal:attributes="href options/portal_url"></a>
"""}

newsletter_plain = {'title': 'Newsletter Template (Plain)',
                    'description': 'Default Newsletter Template.',
                    'mail_subject': "python:'%s - %s'%(options['title'], portal.toPortalTime(modules['DateTime'].DateTime(), 1))",
                    'mail_body':
"""
----------------------------------------------------
<tal:block content="options/title" /> - <tal:block content="python:options['portal'].toPortalTime(modules['DateTime'].DateTime(), 1)" />
----------------------------------------------------
<tal:block content="structure options/message"/>


<tal:block tal:repeat="content options/contents">
<tal:block content="repeat/content/number" />. <tal:block content="content/Title" />
<tal:block content="content/Description" />
<tal:block content="content/absolute_url" />
</tal:block>

_______________________________
<tal:block i18n:translate="label_unsubscribe">Unsubscribe</tal:block> <tal:block content="string:${options/portal_url}/prefs_mynewsletters_form"/>
<tal:block content="options/portal_title" /> <tal:block content="options/portal_url" />
"""}

example_newsletter_html = {'title': 'Example Newsletter Template (HTML)',
                           'description': 'Example Newsletter Template.',
                           'before_script': 'example_script',
                           'mail_subject': "python:'%s - %s'%(options['title'], portal.toPortalTime(modules['DateTime'].DateTime(), 1))",
                           'mail_body':
"""
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<style tal:define="props nocall:here/base_properties">
/* The basic elements: */
body {
    font: &dtml-fontBaseSize; <tal:block content="props/fontFamily"/>;
    background-color: <tal:block content="props/backgroundColor"/>;
    color: <tal:block content="props/fontColor"/>;
    margin: 0;
    padding: 0;
}

a {
    text-decoration: none;
    color: <tal:block content="props/linkColor"/>;
    background-color: transparent;
}
img {
    border: none;
    vertical-align: middle;
}
p {
    margin: 0.5em 0em 1em 0em;
    line-height: 1.5em;
}
p a {
    text-decoration: underline;
}
p a:visited {
    color: <tal:block content="props/linkVisitedColor"/>;
    background-color: transparent;
}
p a:active {
    color: <tal:block content="props/linkActiveColor"/>;
    background-color: transparent;
}
p img {
    border: 0;
    margin: 0;
}

hr {
    height: <tal:block content="props/borderWidth"/>;
    color: <tal:block content="props/globalBorderColor"/>;
    background-color: transparent;
}

h1, h2, h3, h4, h5, h6 {
    color: <tal:block content="props/fontColor"/>;
    background-color: transparent;
    font-family: <tal:block content="props/headingFontFamily"/>;
    font-size: <tal:block content="props/headingFontBaseSize"/>;
    font-weight: normal;
    margin: 0;
    padding-top: 0.5em;
    border-bottom: <tal:block content="string:${props/borderWidth} ${props/borderStyle} ${props/globalBorderColor"/>;
}

h1 a,
h2 a,
h3 a,
h4 a,
h5 a,
h6 a {
    color: <tal:block content="props/fontColor"/> ! important; 
}

h1 {
    font-size: 160%;
}

h2 {
    font-size: 150%;
}

h3 {
    font-size: 140%;
    border-bottom: none;
    font-weight: bold;
}

h4 {
    font-size: 120%;
    border-bottom: none;
    font-weight: bold;
}

h5 {
    font-size: 100%;
    border-bottom: none;
    font-weight: bold;
}

h6 {
    font-size: <tal:block content="props/fontSmallSize"/>;
    border-bottom: none;
    font-weight: bold;
}
.documentDescription {
    font-weight: bold;
    display: block;
    margin: 1em 0em;
    line-height: 1.5em;
}
.documentByLine {
    text-align: left;
    font-size: <tal:block content="props/fontSmallSize"/>;
    clear: both;
    font-weight: normal;
    color: <tal:block content="props/discreetColor"/>;
}
.documentByLine a {
    text-decoration: underline;
}
.eventDetail {
    font-style: italic;
}

</style>

<h1 tal:content="options/title"></h1>
<p tal:content="options/description"></p>
<tal:block content="python:options['portal'].toPortalTime(modules['DateTime'].DateTime(), 1)" />
<br />

<div tal:content="structure options/message"></div>


<div tal:repeat="item options/sorted/items">
<h3 tal:content="python:item[0]"></h3>

<div tal:repeat="content python:item[1][1]">
<h4><img tal:attributes="src python:'cid:%s@portaltransport'%item[1][0]"/>
    <tal:block tal:content="content/Title"/></h4>
  <small class="documentByLine">
    <tal:block i18n:domain="plone" i18n:translate="box_created_by">Created by</tal:block>
    <tal:block content="content/Creator"/>, 
    <tal:block i18n:domain="plone" i18n:translate="box_last_modified">Last modified</tal:block>
    <tal:block content="python:here.toLocalizedTime(content.ModificationDate(), 1)"/>
  </small>
  <div class="eventDetail" tal:content="python:'%s, %s' % (content.location, here.toLocalizedTime(content.start(), 1))" tal:condition="python: content.portal_type in here.portal_calendar.getCalendarTypes()">Place and Time</div>
  <div class="documentDescription">
    <div tal:content="content/Description"></div>
    <a tal:content="content/absolute_url" tal:attributes="href content/absolute_url"></a>
  </div>
  <br />
</div>

</div>

_____________________________<br />
<a tal:attributes="href string:${options/portal_url}/prefs_mynewsletters_form" i18n:translate="label_unsubscribe">Unsubscribe</a><br />
<a tal:content="options/portal_title" tal:attributes="href options/portal_url"></a>
</html>
"""}


personalised_newsletter_html = {'title': 'Personalised Newsletter Template (HTML)',
                           'description': 'Personalised Newsletter Template with logo. You must check "Generate emails for each subscriber".',
                           'before_script': 'personalised_script',
                           'mail_subject': "python:'%s - %s'%(options['title'], portal.toPortalTime(modules['DateTime'].DateTime(), 1))",
                           'mail_body':
"""
<html><body bgcolor="white">
<img src="cid:logo.png@portaltransport" align="right" />
<p tal:condition="options/member|nothing">Dear <span tal:replace="python:options['member'].getProperty('fullname')">member</span>,</p>

<br />
<p tal:content="options/description"></p>
<tal:block content="python:options['portal'].toPortalTime(modules['DateTime'].DateTime(), 1)" />
<br />

<div tal:content="structure options/message"></div>

<div tal:repeat="item options/sorted/items">
<h3 tal:content="python:item[0]"></h3>

<div tal:repeat="content python:item[1][1]">
<h4><img tal:attributes="src python:'cid:%s@portaltransport'%item[1][0]"/>
    <tal:block tal:content="content/Title"/></h4>
  <small class="documentByLine">
    <tal:block i18n:domain="plone" i18n:translate="box_created_by">Created by</tal:block>
    <tal:block content="content/Creator"/>, 
    <tal:block i18n:domain="plone" i18n:translate="box_last_modified">Last modified</tal:block>
    <tal:block content="python:here.toLocalizedTime(content.ModificationDate(), 1)"/>
  </small>
  <div class="eventDetail" tal:content="python:'%s, %s' % (content.location, here.toLocalizedTime(content.start(), 1))" tal:condition="python: content.portal_type in here.portal_calendar.getCalendarTypes()">Place and Time</div>  
  <div class="documentDescription">
    <div tal:content="content/Description"></div>
    <a tal:content="content/absolute_url" tal:attributes="href content/absolute_url"></a>
  </div>
  <br />
</div>

</div>

_____________________________<br />
<a tal:attributes="href string:${options/portal_url}/prefs_mynewsletters_form" i18n:translate="label_unsubscribe">Unsubscribe</a><br />
<a tal:content="options/portal_title" tal:attributes="href options/portal_url"></a>
</body></html>                           
"""}

example_script = """## Script (Python) "example_script"
##parameters=info, headers, charset, text_format, files
##title=Example script

portal = context.portal_url.getPortalObject()
request = context.REQUEST

new_contents = {}
icons = {}

# sorting contents by types
for content in info['contents']:
  tp = content.getTypeInfo()
  ls = new_contents.setdefault(tp.getId(), ['', []])
  icon = tp.getIcon()
  ls[0] = icon
  ls[1].append(content)
  icons[icon] = 1

info['sorted'] = new_contents

# create attached icons
# files format: ('file data', 'content type', 'filename')
for icon in icons:
  ico_ob = getattr(context, icon)
  files.append((ico_ob, ico_ob.content_type, icon)) 

# add email header
headers['X-Organization'] = 'CMFBoard.org'

"""

personalised_script = """## Script (Python) "personalised_script"
##parameters=info, headers, charset, text_format, files
##title=Personalised example script

portal = context.portal_url.getPortalObject()
request = context.REQUEST

mapping = {'Document': 'Documents', 'MPoll': 'Polls', 'ForumFolder': 'Discussion Forums', 'ForumTopic':'Discussion Topics', 'News Item': 'News Items', 'Event': 'Events', 'Link': 'Links'}

new_contents = {}
icons = {}

# sorting contents by types
for content in info['contents']:
  tp = content.getTypeInfo()
  tp_id = tp.getId()
  tp_name = mapping.get(tp_id, '%s' % tp_id)
  ls = new_contents.setdefault(tp_name, ['', []])
  icon = tp.getIcon()
  ls[0] = icon
  ls[1].append(content)
  icons[icon] = 1

info['sorted'] = new_contents


# create attached icons
# files format: ('file data', 'content type', 'filename')
for icon in icons:
  ico_ob = getattr(context, icon)
  files.append((ico_ob, ico_ob.content_type, icon)) 

# add email header
headers['X-Organization'] = 'CMFBoard.org'

# add logo
logo_ob = getattr(context, 'logo.jpg')
# Note: it is good but not essential to use a file extension for the logo
# that reflects the actual file type, e.g. logo.gif, logo.png, logo.jpg etc.
# If you change the default of logo.png, be sure to also change the template
# to reflect this.
files.append((logo_ob, logo_ob.content_type, 'logo.png'))

"""    

templates = {
    PROJECTNAME:
    {'attributes': {'title':'CMFNewsletter mail templates',},
     'templates': {'newsletter_html': newsletter_html,
                   'newsletter_plain': newsletter_plain,
                   'example_newsletter_html': example_newsletter_html,
                   'personalised_newsletter_html': personalised_newsletter_html,
                   },
     'scripts': {'example_script': example_script,
                 'personalised_script': personalised_script,
                 }
     }
    }
