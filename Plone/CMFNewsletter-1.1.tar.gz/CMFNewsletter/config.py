# -*- coding: UTF-8 -*-
# -*- Mode: Python; py-indent-offset: 4 -*-
# Authors: Nik Kim <fafhrd@legco.kz> 
__version__ = '$Revision: 1.12 $'[11:-2]

import os
from Globals import package_home
from Products.CMFCore.CMFCorePermissions import \
     AddPortalContent, ModifyPortalContent, ManagePortal, setDefaultRoles

GLOBALS = globals()

ADD_CONTENT_PERMISSION = AddPortalContent
PROJECTNAME = 'CMFNewsletter'
SKINS_DIR = 'skins'

SendNewsletter = 'CMFNewsletter: Send Newsletter'
setDefaultRoles(SendNewsletter, ('Manager', 'Owner'))

memberData_properties = (
    ('newsletter_format', 'string', 'plain'),
    )

newsletters_slot = 'here/portlet_newsletters/macros/portlet'

mailtemplate_html = 'newsletter_html'
mailtemplate_plain = 'newsletter_plain'

properties = 'cmfnewsletter_properties'
newsletter_properties = (
    ('allow_outside_nl', 'boolean', 0),
    )

mynewsletters_configlet = {
    'id': 'CMFNewsletter_prefs',
    'appId': PROJECTNAME,
    'name': 'Newsletter Subscriptions',
    'action': 'string:$portal_url/prefs_mynewsletters_form',
    'condition': 'not:object/portal_membership/isAnonymousUser',
    'permission': ('View',),
    'category': 'Member',
    'imageUrl': 'mail_icon.gif',
    }

newsletterstool_configlet = {
    'id': 'CMFNewsletter_tool',
    'appId': PROJECTNAME,
    'name': 'Portal Newsletters management',
    'action': 'string:$portal_url/prefs_newsletters',
    'category': 'Products',
    'permission': ('Manage portal',),
    'imageUrl': 'mail_icon.gif',
    }
